<?php $__env->startSection('content'); ?>
    <!-- Header & Navbar -->
    <header id="navbar" class="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
        <div class="container mx-auto px-4 sm:px-6 py-4 flex justify-between items-center">
            <a href="#" class="text-2xl font-display font-bold text-white">
                <?php if(isset($settings['site_logo_path']) && $settings['site_logo_path']): ?>
                    <img src="<?php echo e(asset('storage/' . $settings['site_logo_path'])); ?>" alt="<?php echo e($settings['site_name'] ?? 'Logo'); ?>" class="h-10 w-auto">
                <?php else: ?>
                    <?php echo e(Str::before($settings['site_name'] ?? 'Briket Kita', ' ')); ?><span class="text-amber-400"><?php echo e(Str::after($settings['site_name'] ?? 'Briket Kita', ' ')); ?></span>.
                <?php endif; ?>
            </a>

            <!-- Desktop Nav -->
            <nav class="hidden md:flex items-center space-x-6 lg:space-x-8">
                <a href="#hero" class="hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_home'); ?></a>
                <a href="#tentang" class="hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_about'); ?></a>
                <a href="#produk" class="hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_products'); ?></a>
                <a href="#proses" class="hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_process'); ?></a>
                <a href="#galeri" class="hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_gallery'); ?></a>
                <a href="#kontak" class="hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_contact'); ?></a>
            </nav>

            <!-- Desktop CTA -->
            <div class="hidden md:flex items-center space-x-4">
                <?php if(isset($settings['shopee_url']) && $settings['shopee_url']): ?>
                    <a href="<?php echo e($settings['shopee_url']); ?>" target="_blank" class="text-white hover:text-amber-400" title="Kunjungi Toko Shopee">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                    </a>
                <?php endif; ?>
                <?php if(isset($settings['tokopedia_url']) && $settings['tokopedia_url']): ?>
                    <a href="<?php echo e($settings['tokopedia_url']); ?>" target="_blank" class="text-white hover:text-amber-400" title="Kunjungi Toko Tokopedia">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                    </a>
                <?php endif; ?>
                <a href="https://wa.me/<?php echo e($settings['whatsapp_number'] ?? ''); ?>?text=Halo,%20saya%20tertarik%20dengan%20produk%20briket%20Anda." target="_blank" class="bg-amber-500 text-gray-900 font-bold py-2 px-5 rounded-full hover:bg-amber-400 transition-all duration-300 transform hover:scale-105 text-sm">
                    <?php echo app('translator')->get('messages.order_now'); ?>
                </a>
                <div class="flex space-x-2 text-sm font-semibold">
                    <a href="<?php echo e(route('language.switch', ['locale' => 'en'])); ?>" class="<?php echo e(app()->getLocale() == 'en' ? 'text-amber-400' : 'text-gray-400 hover:text-white'); ?> transition-colors" target="_self">EN</a>
                    <span class="text-gray-500">|</span>
                    <a href="<?php echo e(route('language.switch', ['locale' => 'id'])); ?>" class="<?php echo e(app()->getLocale() == 'id' ? 'text-amber-400' : 'text-gray-400 hover:text-white'); ?> transition-colors" target="_self">ID</a>
                </div>
            </div>

            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button id="mobile-menu-button" class="text-white focus:outline-none">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                </button>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-gray-800/95 backdrop-blur-sm">
            <nav class="flex flex-col items-center space-y-4 py-8">
                <a href="#hero" class="text-lg hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_home'); ?></a>
                <a href="#tentang" class="text-lg hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_about'); ?></a>
                <a href="#produk" class="text-lg hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_products'); ?></a>
                <a href="#proses" class="text-lg hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_process'); ?></a>
                <a href="#galeri" class="text-lg hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_gallery'); ?></a>
                <a href="#kontak" class="text-lg hover:text-amber-400 transition-colors"><?php echo app('translator')->get('messages.nav_contact'); ?></a>
                <div class="pt-4 border-t border-gray-700 w-full flex flex-col items-center space-y-4">
                    <a href="https://wa.me/<?php echo e($settings['whatsapp_number'] ?? ''); ?>?text=Halo,%20saya%20tertarik%20dengan%20produk%20briket%20Anda." target="_blank" class="bg-amber-500 text-gray-900 font-bold py-3 px-8 rounded-full hover:bg-amber-400 transition-all duration-300 w-full max-w-xs text-center">
                        <?php echo app('translator')->get('messages.order_now'); ?>
                    </a>
                    <div class="flex items-center space-x-4">
                        <?php if(isset($settings['shopee_url']) && $settings['shopee_url']): ?>
                            <a href="<?php echo e($settings['shopee_url']); ?>" target="_blank" class="text-white hover:text-amber-400" title="Kunjungi Toko Shopee">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                                </svg>
                            </a>
                        <?php endif; ?>
                        <?php if(isset($settings['tokopedia_url']) && $settings['tokopedia_url']): ?>
                            <a href="<?php echo e($settings['tokopedia_url']); ?>" target="_blank" class="text-white hover:text-amber-400" title="Kunjungi Toko Tokopedia">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                                </svg>
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="flex space-x-2 text-base font-semibold">
                        <a href="<?php echo e(route('language.switch', ['locale' => 'en'])); ?>" class="<?php echo e(app()->getLocale() == 'en' ? 'text-amber-400' : 'text-gray-400 hover:text-white'); ?> transition-colors" target="_self">EN</a>
                        <span class="text-gray-500">|</span>
                        <a href="<?php echo e(route('language.switch', ['locale' => 'id'])); ?>" class="<?php echo e(app()->getLocale() == 'id' ? 'text-amber-400' : 'text-gray-400 hover:text-white'); ?> transition-colors" target="_self">ID</a>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <main>
        <!-- Hero Section -->
        <section id="hero" class="relative min-h-screen flex items-center justify-center bg-cover bg-center" style="background-image: url('<?php echo e(isset($settings['hero_background_image_path']) && $settings['hero_background_image_path'] ? asset('storage/' . $settings['hero_background_image_path']) : ''); ?>'); background-color: <?php echo e(isset($settings['hero_background_image_path']) && $settings['hero_background_image_path'] ? 'transparent' : '#000000'); ?>;">
            <div class="absolute inset-0 bg-black opacity-60"></div>
            <div class="relative text-center text-white p-6 z-10" data-aos="fade-up">
                <h1 class="text-4xl sm:text-5xl md:text-7xl font-display mb-4"><?php echo e($settings['hero_title'] ?? __('messages.hero_title')); ?></h1>
                <p class="text-base sm:text-lg md:text-xl max-w-2xl mx-auto mb-8"><?php echo e($settings['hero_subtitle'] ?? __('messages.hero_subtitle')); ?></p>
                <a href="#produk" class="bg-amber-500 text-gray-900 font-bold py-3 px-8 rounded-full text-lg hover:bg-amber-400 transition-all duration-300 transform hover:scale-105">
                    <?php echo app('translator')->get('messages.hero_button'); ?>
                </a>
            </div>
        </section>

        <!-- Produk Section -->
        <section id="produk" class="py-16 sm:py-20 bg-gray-900">
            <div class="container mx-auto px-4 sm:px-6">
                <div class="text-center mb-10 sm:mb-12" data-aos="fade-up">
                    <h2 class="text-3xl sm:text-4xl font-display text-white"><?php echo app('translator')->get('messages.featured_products_title'); ?></h2>
                    <p class="text-gray-400 mt-2"><?php echo app('translator')->get('messages.featured_products_subtitle'); ?></p>
                </div>
                
                <div class="relative">
                    <div id="product-slider" class="flex overflow-x-auto space-x-6 md:space-x-8 pb-8 scrollbar-hide snap-x snap-mandatory">
                        <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex-shrink-0 w-full sm:w-1/2 md:w-1/2 lg:w-1/3 snap-center">
                            <div class="bg-gray-800 rounded-xl overflow-hidden shadow-lg transform hover:-translate-y-2 transition-transform duration-300 flex flex-col h-full" data-aos="fade-up" data-aos-delay="<?php echo e(($index + 1) * 100); ?>">
                                <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-48 sm:h-56 object-cover">
                                <div class="p-4 sm:p-6 flex flex-col flex-grow">
                                    <h3 class="text-xl sm:text-2xl font-display text-white mb-2"><?php echo e($product->name); ?></h3>
                                    <div class="text-gray-500 text-sm sm:text-base mb-4 line-clamp-3"><?php echo $product->description; ?></div>
                                    <a href="<?php echo e(route('product.detail', $product->slug)); ?>" class="inline-block bg-transparent border border-amber-500 text-amber-500 font-semibold py-2 px-4 sm:px-6 rounded-full hover:bg-amber-500 hover:text-gray-900 transition-all duration-300 self-start mt-auto text-sm sm:text-base">
                                        <?php echo app('translator')->get('messages.view_details'); ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-center text-gray-400 col-span-full"><?php echo app('translator')->get('messages.no_featured_products'); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="absolute inset-y-0 left-0 flex items-center">
                        <button id="prev-product" class="bg-gray-800/50 hover:bg-gray-800 text-white p-2 rounded-full ml-2 focus:outline-none">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                        </button>
                    </div>
                    <div class="absolute inset-y-0 right-0 flex items-center">
                        <button id="next-product" class="bg-gray-800/50 hover:bg-gray-800 text-white p-2 rounded-full mr-2 focus:outline-none">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Tentang Kami Section -->
        <section id="tentang" class="py-16 sm:py-20 bg-gray-800">
            <div class="container mx-auto px-4 sm:px-6">
                <div class="text-center mb-10 sm:mb-12" data-aos="fade-up">
                    <h2 class="text-3xl sm:text-4xl font-display text-white"><?php echo app('translator')->get('messages.about_title'); ?></h2>
                    <p class="text-gray-400 mt-2"><?php echo app('translator')->get('messages.about_subtitle'); ?></p>
                </div>
                <div class="relative max-w-2xl mx-auto">
                    <!-- Garis Timeline -->
                    <div class="absolute left-1/2 transform -translate-x-1/2 h-full border-l-2 border-amber-500/30 hidden md:block"></div>
                    <?php $__empty_1 = true; $__currentLoopData = $timelines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $timeline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <!-- Item Timeline -->
                    <div data-aos="fade-up" class="relative mb-10 sm:mb-12 flex flex-col <?php echo e($index % 2 == 0 ? 'md:flex-row' : 'md:flex-row-reverse'); ?> items-center md:items-start">
                        <div class="md:relative w-10 h-10 sm:w-12 sm:h-12 bg-amber-500 rounded-full border-2 border-amber-500 flex-shrink-0 z-10 flex items-center justify-center text-gray-900 font-bold text-sm sm:text-base <?php echo e($index % 2 == 0 ? 'md:mr-4' : 'md:ml-4'); ?> mb-2 md:mb-0 transform transition-transform duration-300 hover:scale-110">
                            <?php echo e($timeline->year); ?>

                        </div>
                        <div class="w-full <?php echo e($index % 2 == 0 ? 'md:w-1/2 md:pr-8 md:text-right' : 'md:w-1/2 md:pl-8'); ?> text-center md:text-left p-4 rounded-lg bg-gray-900 shadow-lg border border-gray-700">
                            <h3 class="text-xl font-bold text-white mb-1"><?php echo e($timeline->title); ?></h3>
                            <p class="text-gray-400 text-sm"><?php echo e($timeline->description); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center text-gray-400 col-span-full"><?php echo app('translator')->get('messages.no_timeline_data'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Video Profile Section -->
        <section id="video" class="py-16 sm:py-20 bg-gray-800">
            <div class="container mx-auto px-4 sm:px-6">
                <div class="text-center mb-10 sm:mb-12" data-aos="fade-up">
                    <h2 class="text-3xl sm:text-4xl font-display text-white"><?php echo app('translator')->get('messages.video_profile_title'); ?></h2>
                    <p class="text-gray-400 mt-2"><?php echo app('translator')->get('messages.video_profile_subtitle'); ?></p>
                </div>
                <div class="max-w-4xl mx-auto" data-aos="zoom-in">
                    <div class="video-container shadow-2xl aspect-video">
                        <?php if(isset($settings['youtube_video_embed_code']) && $settings['youtube_video_embed_code']): ?>
                        <?php echo $settings['youtube_video_embed_code']; ?>

                        <?php else: ?>
                        <div class="w-full h-full flex items-center justify-center bg-gray-700"><p class="text-gray-400"><?php echo app('translator')->get('messages.video_not_available'); ?></p></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>

        <!-- Proses Kami Section -->
        <section id="proses" class="py-16 sm:py-20 bg-gray-900">
            <div class="container mx-auto px-4 sm:px-6">
                <div class="text-center mb-10 sm:mb-12" data-aos="fade-up">
                    <h2 class="text-3xl sm:text-4xl font-display text-white"><?php echo app('translator')->get('messages.process_title'); ?></h2>
                    <p class="text-gray-400 mt-2"><?php echo app('translator')->get('messages.process_subtitle'); ?></p>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10 text-center">
                    <?php $__empty_1 = true; $__currentLoopData = $processSteps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div data-aos="fade-up" data-aos-delay="<?php echo e(($index + 1) * 100); ?>">
                        <div class="bg-gray-800 border-2 border-amber-500/30 text-amber-500 w-20 h-20 sm:w-24 sm:h-24 mx-auto rounded-full flex items-center justify-center mb-4"><span class="text-3xl sm:text-4xl font-display"><?php echo e($index + 1); ?></span></div>
                        <h3 class="text-xl font-bold text-white mb-2"><?php echo e($step->title); ?></h3>
                        <p class="text-gray-400 text-sm sm:text-base"><?php echo e($step->description); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center text-gray-400 col-span-full"><?php echo app('translator')->get('messages.no_process_steps'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Galeri Section -->
        <section id="galeri" class="py-16 sm:py-20 bg-gray-800">
            <div class="container mx-auto px-4 sm:px-6">
                <div class="text-center mb-10 sm:mb-12" data-aos="fade-up">
                    <h2 class="text-3xl sm:text-4xl font-display text-white"><?php echo app('translator')->get('messages.gallery_title'); ?></h2>
                    <p class="text-gray-400 mt-2"><?php echo app('translator')->get('messages.gallery_subtitle'); ?></p>
                </div>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                    <?php $__empty_1 = true; $__currentLoopData = $galleryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div data-aos="zoom-in">
                            <img class="h-auto max-w-full rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300" src="<?php echo e(asset('storage/' . $item->file_path)); ?>" alt="<?php echo e($item->title ?? 'Gambar Galeri'); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-center text-gray-400 col-span-full"><?php echo app('translator')->get('messages.gallery_empty'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Keunggulan Section -->
        <section id="keunggulan" class="py-16 sm:py-20 bg-gray-900">
            <div class="container mx-auto px-4 sm:px-6">
                <div class="text-center mb-10 sm:mb-12" data-aos="fade-up">
                    <h2 class="text-3xl sm:text-4xl font-display text-white"><?php echo app('translator')->get('messages.why_choose_us_title'); ?></h2>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 text-center">
                    <?php $__empty_1 = true; $__currentLoopData = $advantages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $advantage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div data-aos="fade-up" data-aos-delay="<?php echo e(($index + 1) * 100); ?>">
                        <div class="bg-amber-500 text-gray-900 w-14 h-14 sm:w-16 sm:h-16 mx-auto rounded-full flex items-center justify-center mb-4">
                            <?php if($advantage->icon): ?>
                                <?php echo $advantage->icon; ?>

                            <?php else: ?>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 sm:h-8 sm:w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
                            <?php endif; ?>
                        </div>
                        <h3 class="text-xl font-bold text-white mb-2"><?php echo e($advantage->title); ?></h3>
                        <p class="text-gray-400 text-sm sm:text-base"><?php echo e($advantage->description); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center text-gray-400 col-span-full"><?php echo app('translator')->get('messages.no_advantages'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Contact Form Section -->
        <section id="kontak" class="py-16 sm:py-20 bg-gray-900">
            <div class="container mx-auto px-4 sm:px-6">
                <div class="text-center mb-10 sm:mb-12" data-aos="fade-up">
                    <h2 class="text-3xl sm:text-4xl font-display text-white"><?php echo app('translator')->get('messages.contact_title'); ?></h2>
                    <p class="text-gray-400 mt-2"><?php echo app('translator')->get('messages.contact_subtitle'); ?></p>
                </div>
                <div class="max-w-4xl mx-auto">
                    <?php if(session('success')): ?>
                        <div class="bg-green-500/20 border border-green-500 text-green-300 px-4 py-3 rounded-lg relative mb-6" role="alert">
                            <strong class="font-bold">Berhasil!</strong>
                            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('contact.submit')); ?>" method="POST" class="space-y-6" data-aos="fade-up">
                        <?php echo csrf_field(); ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="name" class="block text-gray-400 mb-2"><?php echo app('translator')->get('messages.contact_form_name'); ?></label>
                                <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" class="w-full bg-gray-800 border border-gray-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-amber-500" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="email" class="block text-gray-400 mb-2"><?php echo app('translator')->get('messages.contact_form_email'); ?></label>
                                <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" class="w-full bg-gray-800 border border-gray-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-amber-500" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="company" class="block text-gray-400 mb-2"><?php echo app('translator')->get('messages.contact_form_company'); ?></label>
                                <input type="text" id="company" name="company" value="<?php echo e(old('company')); ?>" class="w-full bg-gray-800 border border-gray-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-amber-500" required>
                                <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="country" class="block text-gray-400 mb-2"><?php echo app('translator')->get('messages.contact_form_country'); ?></label>
                                <input type="text" id="country" name="country" value="<?php echo e(old('country')); ?>" class="w-full bg-gray-800 border border-gray-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-amber-500" required>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div>
                            <label for="message" class="block text-gray-400 mb-2"><?php echo app('translator')->get('messages.contact_form_message'); ?></label>
                            <textarea id="message" name="message" rows="5" class="w-full bg-gray-800 border border-gray-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-amber-500" required><?php echo e(old('message')); ?></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="bg-amber-500 text-gray-900 font-bold py-3 px-12 rounded-full hover:bg-amber-400 transition-all duration-300 transform hover:scale-105">
                                <?php echo app('translator')->get('messages.contact_form_submit'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800 border-t border-gray-700">
        <div class="container mx-auto px-4 sm:px-6 py-10 sm:py-12">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
                <div>
                    <h3 class="text-2xl font-display font-bold text-white">
                        <?php if(isset($settings['site_logo_path']) && $settings['site_logo_path']): ?>
                            <img src="<?php echo e(asset('storage/' . $settings['site_logo_path'])); ?>" alt="<?php echo e($settings['site_name'] ?? 'Logo'); ?>" class="h-10 w-auto md:mx-0 mx-auto">
                        <?php else: ?>
                            <?php echo e(Str::before($settings['site_name'] ?? 'Briket Kita', ' ')); ?><span class="text-amber-400"><?php echo e(Str::after($settings['site_name'] ?? 'Briket Kita', ' ')); ?></span>.
                        <?php endif; ?>
                    </h3>
                    <p class="text-gray-400 mt-2 text-sm sm:text-base"><?php echo e($settings['hero_subtitle'] ?? __('messages.hero_subtitle')); ?></p>
                    <div class="mt-4">
                        <div class="rounded-lg overflow-hidden shadow-lg inline-block w-full max-w-xs sm:max-w-sm md:max-w-full">
                            <?php if(isset($settings['google_maps_embed_code']) && $settings['google_maps_embed_code']): ?>
                                <?php echo $settings['google_maps_embed_code']; ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div>
                    <h4 class="text-lg font-semibold text-white"><?php echo app('translator')->get('messages.footer_quick_links'); ?></h4>
                    <ul class="mt-4 space-y-2">
                        <li><a href="#produk" class="text-gray-400 hover:text-amber-400 text-sm sm:text-base"><?php echo app('translator')->get('messages.nav_products'); ?></a></li>
                        <li><a href="#video" class="text-gray-400 hover:text-amber-400 text-sm sm:text-base"><?php echo app('translator')->get('messages.nav_process'); ?></a></li>
                        <li><a href="#keunggulan" class="text-gray-400 hover:text-amber-400 text-sm sm:text-base"><?php echo app('translator')->get('messages.why_choose_us_title'); ?></a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-lg font-semibold text-white"><?php echo app('translator')->get('messages.nav_contact'); ?></h4>
                    <p class="text-gray-400 mt-4 text-sm sm:text-base"><?php echo e($settings['company_address'] ?? 'Alamat belum diatur'); ?></p>
                    <p class="text-gray-400 text-sm sm:text-base">Email: <?php echo e($settings['company_email'] ?? 'sales@briketkita.com'); ?></p>
                    <p class="text-amber-400 font-bold mt-2 text-sm sm:text-base">WA: <?php echo e($settings['whatsapp_number'] ?? ''); ?></p>
                </div>
            </div>
            <div class="mt-10 sm:mt-12 border-t border-gray-700 pt-6 text-center text-gray-500 text-sm sm:text-base">
                <p>&copy; <span id="year"></span> <?php echo e($settings['site_name'] ?? 'Briket Kita'); ?>. <?php echo app('translator')->get('messages.all_rights_reserved'); ?></p>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            const navbar = document.getElementById('navbar');

            mobileMenuButton.addEventListener('click', function () {
                mobileMenu.classList.toggle('hidden');
            });

            // Close mobile menu when a link is clicked
            mobileMenu.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    mobileMenu.classList.add('hidden');
                });
            });

            // Navbar scroll effect
            window.addEventListener('scroll', function () {
                if (window.scrollY > 50) {
                    navbar.classList.add('bg-gray-900', 'shadow-lg');
                } else {
                    navbar.classList.remove('bg-gray-900', 'shadow-lg');
                }
            });

            // Product Slider Navigation (if applicable)
            const productSlider = document.getElementById('product-slider');
            const prevProductButton = document.getElementById('prev-product');
            const nextProductButton = document.getElementById('next-product');

            if (productSlider && prevProductButton && nextProductButton) {
                prevProductButton.addEventListener('click', () => {
                    productSlider.scrollBy({ left: -productSlider.offsetWidth, behavior: 'smooth' });
                });

                nextProductButton.addEventListener('click', () => {
                    productSlider.scrollBy({ left: productSlider.offsetWidth, behavior: 'smooth' });
                });
            }

            // Set current year in footer
            document.getElementById('year').textContent = new Date().getFullYear();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\briketpremium\resources\views/pages/home.blade.php ENDPATH**/ ?>